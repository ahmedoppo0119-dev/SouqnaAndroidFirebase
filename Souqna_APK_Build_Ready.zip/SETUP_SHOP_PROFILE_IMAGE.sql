-- إضافة صورة واجهة المحل إلى بيانات سوقنا دون تغيير أي أعمدة أو وظائف أخرى
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS image_url text;

-- ملاحظة: يستخدم التطبيق bucket الموجود souqna-listing-images.
-- تأكد أن الـ bucket عام لعرض الصور، وأن سياسات Storage تسمح للمستخدم المسجل
-- برفع الملفات داخل مجلد يحمل معرّف حسابه فقط. لا تعطل RLS.
