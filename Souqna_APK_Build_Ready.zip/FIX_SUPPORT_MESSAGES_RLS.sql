-- سوقنا: إصلاح آمن لصلاحيات محادثات الدعم
-- شغّل هذا الملف في Supabase SQL Editor. لا يعطّل RLS ولا يسمح بالكتابة العامة.

alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;

grant select, insert, update on public.support_tickets to authenticated;
grant select, insert on public.support_messages to authenticated;
grant usage, select on sequence public.support_tickets_id_seq, public.support_messages_id_seq to authenticated;

drop policy if exists support_tickets_select_owner_admin on public.support_tickets;
create policy support_tickets_select_owner_admin on public.support_tickets
for select to authenticated
using (user_id = (select auth.uid()) or public.souqna_is_admin() is true);

drop policy if exists support_tickets_insert_owner on public.support_tickets;
create policy support_tickets_insert_owner on public.support_tickets
for insert to authenticated
with check (user_id = (select auth.uid()));

drop policy if exists support_tickets_update_owner_admin on public.support_tickets;
create policy support_tickets_update_owner_admin on public.support_tickets
for update to authenticated
using (user_id = (select auth.uid()) or public.souqna_is_admin() is true)
with check (user_id = (select auth.uid()) or public.souqna_is_admin() is true);

drop policy if exists support_messages_select_owner_admin on public.support_messages;
create policy support_messages_select_owner_admin on public.support_messages
for select to authenticated
using (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = (select auth.uid()) or public.souqna_is_admin() is true)));

drop policy if exists support_messages_insert_customer_admin on public.support_messages;
create policy support_messages_insert_customer_admin on public.support_messages
for insert to authenticated
with check (sender_id = (select auth.uid()) and (
 (sender_role = 'customer' and exists (select 1 from public.support_tickets t where t.id = ticket_id and t.user_id = (select auth.uid())))
 or (sender_role = 'admin' and public.souqna_is_admin() is true and exists (select 1 from public.support_tickets t where t.id = ticket_id))
));

-- اختبار تشخيصي آمن: يعرض وجود الدالة والسياسات، ولا يكشف رسائل المستخدمين.
select tablename, policyname, cmd, roles from pg_policies
where schemaname = 'public' and tablename in ('support_tickets','support_messages')
order by tablename, policyname;
