-- سوقنا: إعداد نوع التمييز ومدده وأسعاره المقترحة
-- شغّل هذا الملف في Supabase SQL Editor قبل اختبار اختيار نوع التمييز.
-- الأسعار الموجودة في واجهة التطبيق تجريبية؛ اعتمد الأسعار النهائية قبل استقبال أي مدفوعات.
alter table public.product_promotions
  add column if not exists promotion_type text not null default 'search_feature';

alter table public.product_promotions
  add column if not exists amount_egp numeric(10,2) not null default 50;

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'product_promotions_type_check') then
    alter table public.product_promotions add constraint product_promotions_type_check
      check (promotion_type in ('search_feature','home_spotlight'));
  end if;
end $$;

comment on column public.product_promotions.promotion_type is 'search_feature = تمييز في نتائج البحث; home_spotlight = ظهور في قسم المنتجات المميزة';
comment on column public.product_promotions.amount_egp is 'السعر المعروض للطلب بالجنيه المصري؛ لا يثبت الدفع ولا يؤكد التحصيل';
