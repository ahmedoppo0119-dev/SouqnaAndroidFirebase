import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return reply({error:"Method not allowed"},405);
 const url=Deno.env.get("SUPABASE_URL")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
 const auth=req.headers.get("Authorization")||""; if(!auth.startsWith("Bearer "))return reply({error:"يلزم تسجيل الدخول"},401);
 const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
 const {data:{user},error:userErr}=await userClient.auth.getUser(); if(userErr||!user)return reply({error:"جلسة الدخول غير صالحة"},401);
 const {data:isAdmin,error:adminErr}=await userClient.rpc("souqna_is_admin"); if(adminErr||isAdmin!==true)return reply({error:"غير مصرح: هذه العملية للمسؤول فقط"},403);
 const admin=createClient(url,service,{auth:{autoRefreshToken:false,persistSession:false}});
 let body:any; try{body=await req.json()}catch{return reply({error:"بيانات الطلب غير صالحة"},400)}
 const action=String(body.action||"");
 async function findUser(id:string){const {data,error}=await admin.auth.admin.getUserById(id);if(error||!data?.user)throw new Error("الحساب غير موجود");return data.user;}
 async function accountShape(u:any){
  const rawRole=String(u.app_metadata?.role||u.user_metadata?.account_type||u.user_metadata?.role||"").trim().toLowerCase();
  const traderRoles=["merchant","trader","seller","shop_owner","shopowner","store_owner","vendor","تاجر","صاحب محل","مالك محل"];
  let accountType=traderRoles.includes(rawRole)?"تاجر":"";
  if(!accountType){
    const {data:shop}=await admin.from("shops").select("id").eq("owner_id",u.id).limit(1).maybeSingle();
    accountType=shop?"تاجر":"عميل";
  }
  const prefix=accountType==="تاجر"?"T":"C";
  const code=`SQ-${prefix}-${String(u.id).replaceAll("-","").slice(0,8).toUpperCase()}`;
  return {id:u.id,account_code:code,legacy_account_code:"SQ-"+String(u.id).replaceAll("-","").slice(0,8).toUpperCase(),email:u.email||"",display_name:u.user_metadata?.display_name||u.user_metadata?.full_name||u.user_metadata?.name||"",created_at:u.created_at,account_type:accountType,suspended:!!(u.banned_until&&new Date(u.banned_until).getTime()>Date.now())};
 }
 try{
  if(action==="list_customers"){
   const accounts:any[]=[]; let page=1;
   while(page<=20){
    const {data,error}=await admin.auth.admin.listUsers({page,perPage:100});
    if(error)throw error;
    const users=data.users||[];
    for(const u of users){const shaped=await accountShape(u);if(shaped.account_type==="عميل")accounts.push(shaped);}
    if(users.length<100)break; page++;
   }
   accounts.sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
   return reply({accounts});
  }
  if(action==="search"){
   const code=String(body.account_code||"").trim().toUpperCase();
   const modern=/^SQ-([CT])-([A-F0-9]{8})$/.exec(code);
   const legacy=/^SQ-([A-F0-9]{8})$/.exec(code);
   if(!modern&&!legacy)return reply({error:"صيغة كود الحساب غير صحيحة. استخدم SQ-C-XXXXXXXX للعميل أو SQ-T-XXXXXXXX للتاجر."},400);
   const prefix=modern?.[1]||null, suffix=(modern?.[2]||legacy?.[1])!;
   let page=1,found=null;
   while(page<=20&&!found){
     const {data,error}=await admin.auth.admin.listUsers({page,perPage:100});
     if(error)throw error;
     const users=data.users||[];
     for(const u of users){
       const clean=String(u.id).replaceAll("-","").slice(0,8).toUpperCase();
       if(clean!==suffix) continue;
       const shaped=await accountShape(u);
       if(!prefix || shaped.account_type===(prefix==="T"?"تاجر":"عميل")) { found=shaped; break; }
     }
     if(users.length<100)break;
     page++;
   }
   return reply({account:found});
  }
  const id=String(body.user_id||"");if(!/^[0-9a-f-]{36}$/i.test(id))return reply({error:"معرّف الحساب غير صالح"},400);
  if(id===user.id)return reply({error:"لا يمكن للمسؤول حذف أو إيقاف حسابه الحالي من هذه الشاشة"},400);
  if(action==="update"){
   const email=String(body.email||"").trim();const display_name=String(body.display_name||"").trim();if(!email.includes("@"))return reply({error:"البريد الإلكتروني غير صالح"},400);
   const existing=await findUser(id);const metadata={...(existing.user_metadata||{}),display_name};const {data,error}=await admin.auth.admin.updateUserById(id,{email,user_metadata:metadata});if(error)throw error;return reply({account:await accountShape(data.user)});
  }
  if(action==="suspend"){
   const suspend=body.suspend===true;const {data,error}=await admin.auth.admin.updateUserById(id,{ban_duration:suspend?"876000h":"none"});if(error)throw error;return reply({account:await accountShape(data.user)});
  }
  if(action==="delete"){
   if(body.confirmation!=="DELETE")return reply({error:"تأكيد الحذف مطلوب"},400);
   const {error}=await admin.auth.admin.deleteUser(id);if(error)throw error;return reply({ok:true});
  }
  return reply({error:"إجراء غير معروف"},400);
 }catch(e){return reply({error:e instanceof Error?e.message:"حدث خطأ غير متوقع"},500)}
});
